const fs = require('fs');
const path = require('path');

module.exports = {
  load(client) {
    const eventsPath = path.join(__dirname, '../events');
    const discordFiles = fs.readdirSync(eventsPath).filter(f => f.endsWith('.js'));

    for (const file of discordFiles) {
      const event = require(path.join(eventsPath, file));
      if (!event.name) continue;
      if (event.once) client.once(event.name, (...args) => event.execute(...args, client));
      else client.on(event.name, (...args) => event.execute(...args, client));
    }

    const lavalinkPath = path.join(__dirname, '../events/lavalink');
    const lavalinkFiles = fs.readdirSync(lavalinkPath).filter(f => f.endsWith('.js'));

    for (const file of lavalinkFiles) {
      const event = require(path.join(lavalinkPath, file));
      if (!event.name) continue;
      client.lavalink.on(event.name, (...args) => event.execute(...args, client));
    }

    console.log(`✅ تم تحميل ${discordFiles.length} حدث ديسكورد + ${lavalinkFiles.length} حدث Lavalink`);
  },
};
