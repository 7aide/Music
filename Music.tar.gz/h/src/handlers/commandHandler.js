const fs = require('fs');
const path = require('path');
const { Collection } = require('discord.js');
const { PREFIX } = require('../../config/bot');
const embeds = require('../utils/embeds');

module.exports = {
  load(client) {
    client.commands = new Collection();
    const commandsPath = path.join(__dirname, '../commands');
    const files = fs.readdirSync(commandsPath).filter(f => f.endsWith('.js'));

    for (const file of files) {
      const command = require(path.join(commandsPath, file));
      if (!command.name) { console.warn(`⚠️  ${file} لا يحتوي على name`); continue; }
      client.commands.set(command.name.toLowerCase(), command);
      if (Array.isArray(command.aliases)) {
        command.aliases.forEach(alias => client.commands.set(alias.toLowerCase(), command));
      }
    }

    console.log(`✅ تم تحميل ${files.length} أمر`);
  },

  handle(client) {
    client.on('messageCreate', async (message) => {
      if (message.author.bot || !message.guild) return;
      if (!message.content.startsWith(PREFIX)) return;

      const args = message.content.slice(PREFIX.length).trim().split(/ +/);
      const commandName = args.shift().toLowerCase();
      const command = client.commands.get(commandName);
      if (!command) return;

      try {
        await command.execute(message, args, client);
      } catch (err) {
        console.error(`❌ خطأ في أمر ${commandName}:`, err);
        message.reply({ embeds: [embeds.error(`حدث خطأ: ${err.message}`)] }).catch(() => {});
      }
    });
  },
};
