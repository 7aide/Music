const embeds = require('../utils/embeds');
const checks = require('../utils/checks');
const { formatTime } = require('../utils/embeds');

module.exports = {
  name: 'seek',
  aliases: ['انتقل'],
  description: 'انتقل إلى وقت محدد في الأغنية',
  usage: '<1:30> أو <90> بالثواني',

  async execute(message, args, client) {
    const { player, error } = checks.fullCheck(message, client);
    if (error) return message.reply({ embeds: [embeds.error(error)] });

    if (!player.queue.current)
      return message.reply({ embeds: [embeds.error('لا تُشغَّل أيُّ أغنية الآن!')] });

    if (!player.queue.current.info.isSeekable)
      return message.reply({ embeds: [embeds.error('هذه الأغنية لا تدعم الانتقال إلى وقت محدد!')] });

    if (!args[0])
      return message.reply({ embeds: [embeds.error('يرجى تحديد الوقت. مثال: `!seek 1:30` أو `!seek 90`')] });

    let ms;
    if (args[0].includes(':')) {
      const parts = args[0].split(':').map(Number);
      if (parts.length === 2) ms = (parts[0] * 60 + parts[1]) * 1000;
      else if (parts.length === 3) ms = (parts[0] * 3600 + parts[1] * 60 + parts[2]) * 1000;
    } else {
      ms = parseInt(args[0]) * 1000;
    }

    if (isNaN(ms) || ms < 0)
      return message.reply({ embeds: [embeds.error('وقت غير صحيح. مثال: `!seek 1:30`')] });

    const duration = player.queue.current.info.duration;
    if (ms > duration)
      return message.reply({ embeds: [embeds.error(`الوقت المحدد يتجاوز مدة الأغنية! (${formatTime(duration)})`)] });

    await player.seek(ms);
    message.reply({ embeds: [embeds.success(`⏩  تم الانتقال إلى \`${formatTime(ms)}\`.`)] });
  },
};
