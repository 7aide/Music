const embeds = require('../utils/embeds');

module.exports = {
  name: 'queue',
  aliases: ['q', 'list', 'القائمة'],
  description: 'اعرض قائمة الانتظار',
  usage: '[رقم الصفحة]',

  async execute(message, args, client) {
    const player = client.lavalink.getPlayer(message.guild.id);
    if (!player || (!player.queue.current && !player.queue.tracks.length))
      return message.reply({ embeds: [embeds.error('قائمة الانتظار فارغة!')] });

    const perPage = 10;
    const totalTracks = player.queue.tracks.length;
    const totalPages = Math.ceil(totalTracks / perPage) || 1;
    let page = parseInt(args[0]) || 1;
    page = Math.max(1, Math.min(page, totalPages));

    message.reply({ embeds: [embeds.queue(player, page)] });
  },
};
