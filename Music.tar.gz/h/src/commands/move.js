const embeds = require('../utils/embeds');
const checks = require('../utils/checks');

module.exports = {
  name: 'move',
  aliases: ['mv', 'نقل'],
  description: 'انقل أغنيةً في قائمة الانتظار من موقع إلى آخر',
  usage: '<من> <إلى>',

  async execute(message, args, client) {
    const { player, error } = checks.fullCheck(message, client);
    if (error) return message.reply({ embeds: [embeds.error(error)] });

    if (!args[0] || !args[1])
      return message.reply({ embeds: [embeds.error('يرجى تحديد موقعين. مثال: `!move 3 1`')] });

    const from = parseInt(args[0]) - 1;
    const to = parseInt(args[1]) - 1;
    const tracks = player.queue.tracks;

    if (isNaN(from) || from < 0 || from >= tracks.length)
      return message.reply({ embeds: [embeds.error(`الموقع الأول غير صحيح! تحتوي القائمة على ${tracks.length} أغنية.`)] });

    if (isNaN(to) || to < 0 || to >= tracks.length)
      return message.reply({ embeds: [embeds.error(`الموقع الثاني غير صحيح! تحتوي القائمة على ${tracks.length} أغنية.`)] });

    const [track] = tracks.splice(from, 1);
    tracks.splice(to, 0, track);

    message.reply({
      embeds: [embeds.success(`↕️  تم نقل **${track.info.title.slice(0, 50)}** من الموقع \`${from + 1}\` إلى الموقع \`${to + 1}\`.`)],
    });
  },
};
