const embeds = require('../utils/embeds');
const checks = require('../utils/checks');

module.exports = {
  name: 'shuffle',
  aliases: ['mix', 'خلط'],
  description: 'اخلط قائمة الانتظار عشوائياً',

  async execute(message, args, client) {
    const { player, error } = checks.fullCheck(message, client);
    if (error) return message.reply({ embeds: [embeds.error(error)] });

    if (player.queue.tracks.length < 2)
      return message.reply({ embeds: [embeds.error('يجب أن تحتوي القائمة على أغنيتين على الأقل!')] });

    player.queue.shuffle();
    message.reply({ embeds: [embeds.success(`🔀  تم خلط **${player.queue.tracks.length}** أغنية عشوائياً.`)] });
  },
};
