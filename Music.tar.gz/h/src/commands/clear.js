const embeds = require('../utils/embeds');
const checks = require('../utils/checks');

module.exports = {
  name: 'clear',
  aliases: ['cls', 'مسح'],
  description: 'امسح قائمة الانتظار كاملةً دون إيقاف الأغنية الحالية',

  async execute(message, args, client) {
    const { player, error } = checks.fullCheck(message, client);
    if (error) return message.reply({ embeds: [embeds.error(error)] });

    const count = player.queue.tracks.length;
    if (count === 0)
      return message.reply({ embeds: [embeds.warning('قائمة الانتظار فارغة بالفعل!')] });

    player.queue.splice(0, count);
    message.reply({ embeds: [embeds.success(`  تم مسح **${count}** أغنية من قائمة الانتظار.`)] });
  },
};
