const { EmbedBuilder } = require('discord.js');
const { COLORS, PREFIX } = require('../../config/bot');

const COMMANDS = {
  '  تشغيل': [
    ['play <أغنية/رابط>', 'شغِّل من يوتيوب أو سبوتيفاي أو ساوندكلاود'],
    ['search <أغنية>', 'ابحث واختر من النتائج'],
  ],
  '  تحكم': [
    ['pause', 'أوقِف الأغنية مؤقتاً'],
    ['resume', 'استأنِف التشغيل'],
    ['skip [عدد]', 'تخطَّ الأغنية (يمكن تخطي عدة أغانٍ)'],
    ['previous', 'شغِّل الأغنية السابقة'],
    ['stop', 'أوقِف الموسيقى وامسح القائمة واخرج'],
    ['seek <وقت>', 'انتقل إلى وقت محدد (1:30 أو 90)'],
    ['volume <1-100>', 'اضبط مستوى الصوت'],
    ['loop <0/1/2>', 'التكرار: 0=لا يوجد  1=أغنية  2=قائمة'],
  ],
  '  قائمة الانتظار': [
    ['queue [صفحة]', 'اعرض قائمة الانتظار'],
    ['nowplaying', 'اعرض الأغنية الحالية مع شريط التقدم'],
    ['shuffle', 'اخلط القائمة عشوائياً'],
    ['remove <رقم>', 'احذف أغنيةً من القائمة'],
    ['move <من> <إلى>', 'انقل أغنيةً في القائمة'],
    ['clear', 'امسح القائمة كاملةً'],
  ],
};

module.exports = {
  name: 'help',
  aliases: ['h', 'مساعدة'],
  description: 'اعرض قائمة الأوامر',

  async execute(message, args, client) {
    const embed = new EmbedBuilder()
      .setColor(COLORS.PRIMARY)
      .setAuthor({ name: `${client.user.username}  —  بوت الموسيقى`, iconURL: client.user.displayAvatarURL() })
      .setTitle(' قائمة الأوامر')
      .setDescription(`البادئة: \`${PREFIX}\`  —  مثال: \`${PREFIX}play أي شيء\``)
      .setThumbnail(client.user.displayAvatarURL());

    for (const [category, commands] of Object.entries(COMMANDS)) {
      embed.addFields({
        name: category,
        value: commands.map(([cmd, desc]) => `\`${PREFIX}${cmd}\`  —  ${desc}`).join('\n'),
        inline: false,
      });
    }

   

    message.reply({ embeds: [embed] });
  },
};
