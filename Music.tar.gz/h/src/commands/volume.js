const embeds = require('../utils/embeds');
const checks = require('../utils/checks');

module.exports = {
  name: 'volume',
  aliases: ['vol', 'v', 'الصوت'],
  description: 'اضبط مستوى الصوت (1-100)',
  usage: '<1-100>',

  async execute(message, args, client) {
    const { player, error } = checks.fullCheck(message, client);
    if (error) return message.reply({ embeds: [embeds.error(error)] });

    if (!args[0]) {
      const bar = embeds.volumeBar(player.volume);
      return message.reply({
        embeds: [embeds.info(`🔊  **مستوى الصوت الحالي:** ${bar}  \`${player.volume}%\``)],
      });
    }

    const vol = parseInt(args[0]);
    if (isNaN(vol) || vol < 1 || vol > 100)
      return message.reply({ embeds: [embeds.error('يرجى إدخال رقم بين **1** و **100**!')] });

    await player.setVolume(vol, true);
    const bar = embeds.volumeBar(vol);
    message.reply({ embeds: [embeds.success(`🔊  **تم ضبط مستوى الصوت:** ${bar}  \`${vol}%\``)] });
  },
};
