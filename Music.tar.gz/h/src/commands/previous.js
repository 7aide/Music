const embeds = require('../utils/embeds');
const checks = require('../utils/checks');

module.exports = {
  name: 'previous',
  aliases: ['prev', 'back', 'السابقة'],
  description: 'شغِّل الأغنية السابقة من السجل',

  async execute(message, args, client) {
    const { player, error } = checks.fullCheck(message, client);
    if (error) return message.reply({ embeds: [embeds.error(error)] });

    const prev = player.queue.previous?.[0];
    if (!prev)
      return message.reply({ embeds: [embeds.error('لا توجد أغنية سابقة في السجل!')] });

    await player.queue.add(prev, 0);
    await player.skip();
    message.reply({ embeds: [embeds.success(`⏮️  العودة إلى: **${prev.info.title.slice(0, 60)}**`)] });
  },
};
