const embeds = require('../utils/embeds');
const checks = require('../utils/checks');

module.exports = {
  name: 'skip',
  aliases: ['s', 'next', 'تخطى'],
  description: 'تخطَّ الأغنية الحالية',
  usage: '[عدد الأغاني]',

  async execute(message, args, client) {
    const { player, error } = checks.fullCheck(message, client);
    if (error) return message.reply({ embeds: [embeds.error(error)] });

    const skipCount = parseInt(args[0]) || 1;

    if (!player.queue.current)
      return message.reply({ embeds: [embeds.error('لا تُشغَّل أيُّ أغنية الآن!')] });

    if (player.queue.tracks.length === 0) {
      await player.stopPlaying(true, false);
      return message.reply({ embeds: [embeds.success('⏭️  تم تخطي الأغنية — انتهت القائمة!')] });
    }

    const skipped = player.queue.current.info.title;

    if (skipCount > 1) {
      const toRemove = Math.min(skipCount - 1, player.queue.tracks.length);
      player.queue.splice(0, toRemove);
    }

    await player.skip();

    message.reply({
      embeds: [embeds.success(`⏭️  تم تخطي: **${skipped.slice(0, 60)}**${skipCount > 1 ? `  (+${skipCount - 1} أغنية)` : ''}`)],
    });
  },
};
