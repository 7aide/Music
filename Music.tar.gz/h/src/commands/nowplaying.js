const embeds = require('../utils/embeds');
const playerStore = require('../utils/playerStore');

module.exports = {
  name: 'nowplaying',
  aliases: ['np', 'الآن', 'الان'],
  description: 'اعرض الأغنية الحالية مع شريط تقدم مباشر',

  async execute(message, args, client) {
    const player = client.lavalink.getPlayer(message.guild.id);

    if (!player || !player.queue.current)
      return message.reply({ embeds: [embeds.error('لا تُشغَّل أيُّ أغنية الآن!')] });

    const track = player.queue.current;

    const sentMsg = await message.reply({
      embeds: [embeds.nowPlaying(player, track, client)],
    });

    playerStore.clear(message.guild.id);

    const interval = setInterval(async () => {
      const currentPlayer = client.lavalink.getPlayer(message.guild.id);

      if (!currentPlayer || !currentPlayer.queue.current) {
        playerStore.clear(message.guild.id);
        sentMsg.edit({
          embeds: [
            embeds.nowPlaying(player, track, client)
          ],
        }).catch(() => {});
        return;
      }

      sentMsg.edit({
        embeds: [embeds.nowPlaying(currentPlayer, currentPlayer.queue.current, client)],
      }).catch(() => {
        playerStore.clear(message.guild.id);
      });
    }, 5000);

    playerStore.set(message.guild.id, { interval, message: sentMsg });
  },
};
