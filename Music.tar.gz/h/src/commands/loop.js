const embeds = require('../utils/embeds');
const checks = require('../utils/checks');

module.exports = {
  name: 'loop',
  aliases: ['repeat', 'تكرار'],
  description: 'تفعيل أو تعطيل تكرار الأغنية الحالية',

  async execute(message, args, client) {
    const { player, error } = checks.fullCheck(message, client);
    if (error) return message.reply({ embeds: [embeds.error(error)] });

    if (!player.queue.current)
      return message.reply({ embeds: [embeds.error('لا تُشغَّل أيُّ أغنية الآن!')] });

    const isLooping = player.repeatMode === 'track';
    const newMode   = isLooping ? 'off' : 'track';

    await player.setRepeatMode(newMode);

    if (newMode === 'track') {
      message.reply({ embeds: [embeds.success('🔂  تم تفعيل التكرار — ستُعاد الأغنية تلقائياً.')] });
    } else {
      message.reply({ embeds: [embeds.success('➡️  تم تعطيل التكرار.')] });
    }
  },
};
