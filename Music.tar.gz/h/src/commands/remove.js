const embeds = require('../utils/embeds');
const checks = require('../utils/checks');

module.exports = {
  name: 'remove',
  aliases: ['rm', 'del', 'احذف'],
  description: 'احذف أغنيةً من قائمة الانتظار برقمها',
  usage: '<رقم الأغنية>',

  async execute(message, args, client) {
    const { player, error } = checks.fullCheck(message, client);
    if (error) return message.reply({ embeds: [embeds.error(error)] });

    if (!args[0])
      return message.reply({ embeds: [embeds.error('يرجى تحديد رقم الأغنية. مثال: `!remove 3`')] });

    const index = parseInt(args[0]) - 1;
    const tracks = player.queue.tracks;

    if (isNaN(index) || index < 0 || index >= tracks.length)
      return message.reply({ embeds: [embeds.error(`رقم غير صحيح! تحتوي القائمة على **${tracks.length}** أغنية.`)] });

    const removed = tracks[index];
    player.queue.splice(index, 1);
    message.reply({ embeds: [embeds.success(`🗑️  تم حذف: **${removed.info.title.slice(0, 60)}**`)] });
  },
};
