const embeds = require('../utils/embeds');
const checks = require('../utils/checks');

module.exports = {
  name: 'pause',
  aliases: ['وقف'],
  description: 'أوقِف الأغنية مؤقتاً',

  async execute(message, args, client) {
    const { player, error } = checks.fullCheck(message, client);
    if (error) return message.reply({ embeds: [embeds.error(error)] });

    if (player.paused)
      return message.reply({ embeds: [embeds.warning('الأغنية موقوفة بالفعل! اكتب `!resume` لاستئنافها.')] });

    if (!player.playing)
      return message.reply({ embeds: [embeds.error('لا تُشغَّل أيُّ أغنية الآن!')] });

    await player.pause();
    message.reply({ embeds: [embeds.success('⏸️  تم إيقاف الأغنية مؤقتاً.')] });
  },
};
