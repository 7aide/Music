const { EmbedBuilder } = require('discord.js');
const embeds = require('../utils/embeds');
const checks = require('../utils/checks');
const { COLORS, SEARCH_PLATFORM } = require('../../config/bot');

module.exports = {
  name: 'search',
  aliases: ['بحث'],
  description: 'ابحث عن أغنية واختر من النتائج',
  usage: '<اسم الأغنية>',

  async execute(message, args, client) {
    const vcErr = checks.voiceChecks(message);
    if (vcErr) return message.reply({ embeds: [embeds.error(vcErr)] });

    const query = args.join(' ');
    if (!query)
      return message.reply({ embeds: [embeds.error('يرجى كتابة اسم الأغنية. مثال: `!search Bohemian Rhapsody`')] });

    let player = client.lavalink.getPlayer(message.guild.id);
    const voiceChannel = message.member.voice.channel;

    if (!player) {
      player = await client.lavalink.createPlayer({
        guildId: message.guild.id,
        voiceChannelId: voiceChannel.id,
        textChannelId: message.channel.id,
        selfDeaf: true,
        volume: parseInt(process.env.DEFAULT_VOLUME) || 80,
      });
    }

    const res = await player.search({ query, source: SEARCH_PLATFORM }, message.author).catch(() => null);
    if (!res?.tracks?.length)
      return message.reply({ embeds: [embeds.error(`لم يُعثر على نتائج لـ: \`${query}\``)] });

    const top10 = res.tracks.slice(0, 10);
    const list = top10
      .map((t, i) => `\`${i + 1}.\`  **${t.info.title.slice(0, 55)}**\n　　👤 ${t.info.author}  •  ⏱️ ${embeds.formatTime(t.info.duration)}`)
      .join('\n\n');

    const searchEmbed = new EmbedBuilder()
      .setColor(COLORS.INFO)
      .setTitle(`🔍  نتائج البحث: "${query.slice(0, 40)}"`)
      .setDescription(`${list}\n\n📩  **أرسل رقم الأغنية (1-${top10.length}) أو \`إلغاء\` للإلغاء**`)
      .setFooter({ text: 'لديك 30 ثانية للاختيار' });

    const searchMsg = await message.reply({ embeds: [searchEmbed] });

    const filter = (m) => m.author.id === message.author.id && m.channelId === message.channelId;
    const collected = await message.channel
      .awaitMessages({ filter, max: 1, time: 30_000, errors: ['time'] })
      .catch(() => null);

    await searchMsg.delete().catch(() => {});

    if (!collected) {
      if (!player.queue.current) player.destroy().catch(() => {});
      return message.reply({ embeds: [embeds.warning('انتهى الوقت! تم إلغاء البحث.')] });
    }

    const reply = collected.first();
    await reply.delete().catch(() => {});

    if (reply.content.toLowerCase() === 'إلغاء' || reply.content.toLowerCase() === 'cancel') {
      if (!player.queue.current) player.destroy().catch(() => {});
      return message.reply({ embeds: [embeds.warning('تم إلغاء البحث.')] });
    }

    const choice = parseInt(reply.content);
    if (isNaN(choice) || choice < 1 || choice > top10.length)
      return message.reply({ embeds: [embeds.error('اختيار غير صحيح!')] });

    const track = top10[choice - 1];
    track.requester = message.author;

    await player.queue.add(track);
    if (!player.connected) await player.connect();
    if (!player.playing && !player.paused) {
      await player.play();
      // رسالة عادية (نص) وليس embed
      await message.channel.send({ content: embeds.playStarted(track) });
    } else {
      message.reply({ embeds: [embeds.trackAdded(track, player.queue.tracks.length)] });
    }
  },
};
