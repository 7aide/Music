const embeds = require('../utils/embeds');
const checks = require('../utils/checks');
const { SEARCH_PLATFORM } = require('../../config/bot');

module.exports = {
  name: 'play',
  aliases: ['p', 'شغل', 'بشغل'],
  description: 'شغِّل أغنيةً أو قائمةَ تشغيل',
  usage: '<رابط أو اسم الأغنية>',

  async execute(message, args, client) {
    const vcErr = checks.voiceChecks(message);
    if (vcErr) return message.reply({ embeds: [embeds.error(vcErr)] });

    const query = args.join(' ');
    if (!query) {
      return message.reply({
        embeds: [embeds.error('يرجى كتابة اسم الأغنية أو الرابط.\nمثال: `!play Blinding Lights`')],
      });
    }

    const voiceChannel = message.member.voice.channel;
    let player = client.lavalink.getPlayer(message.guild.id);

    if (!player) {
      const connectedNode = [...client.lavalink.nodeManager.nodes.values()].find(n => n.connected);
      if (!connectedNode) {
        return message.reply({ embeds: [embeds.error('لا توجد عقدة Lavalink متصلة. تأكد من تشغيل الخادم.')] });
      }
      player = await client.lavalink.createPlayer({
        guildId: message.guild.id,
        voiceChannelId: voiceChannel.id,
        textChannelId: message.channel.id,
        selfDeaf: true,
        selfMute: false,
        volume: parseInt(process.env.DEFAULT_VOLUME) || 80,
        instaUpdateFiltersFix: true,
      });
    }

    if (!player.connected) await player.connect();

    const searchMsg = await message.reply({
      embeds: [embeds.info(`🔍  **جارٍ البحث عن:** \`${query}\``)],
    });

    try {
      const res = await player.search(
        { query, source: query.startsWith('http') ? undefined : SEARCH_PLATFORM },
        message.author
      );

      if (!res || !res.tracks?.length) {
        await searchMsg.edit({ embeds: [embeds.error(`لم يُعثر على نتائج لـ: \`${query}\``)] });
        if (!player.queue.current) player.destroy().catch(() => {});
        return;
      }

      const wasPlayingBefore = player.playing || player.paused;

      if (res.loadType === 'playlist') {
        await player.queue.add(res.tracks);
        await searchMsg.edit({ embeds: [embeds.playlistAdded(res.playlist, res.tracks.length)] });
        if (!wasPlayingBefore) await player.play({ paused: false });
      } else {
        const track = res.tracks[0];
        await player.queue.add(track);

        if (wasPlayingBefore) {
          await searchMsg.edit({ embeds: [embeds.trackAdded(track, player.queue.tracks.length)] });
        } else {
          await searchMsg.delete().catch(() => {});
          await player.play({ paused: false });
          // رسالة عادية (نص) وليس embed
          await message.channel.send({ content: embeds.playStarted(track) });
        }
      }

    } catch (err) {
      console.error('Play Error:', err);
      await searchMsg.edit({ embeds: [embeds.error(`حدث خطأ أثناء التشغيل: ${err.message}`)] }).catch(() => {});
      if (!player.queue.current) player.destroy().catch(() => {});
    }
  },
};
