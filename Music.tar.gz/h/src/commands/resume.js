const embeds = require('../utils/embeds');
const checks = require('../utils/checks');

module.exports = {
  name: 'resume',
  aliases: ['r', 'continue', 'استئناف'],
  description: 'استأنِف تشغيل الأغنية',

  async execute(message, args, client) {
    const { player, error } = checks.fullCheck(message, client);
    if (error) return message.reply({ embeds: [embeds.error(error)] });

    if (!player.paused)
      return message.reply({ embeds: [embeds.warning('الأغنية تُشغَّل بالفعل!')] });

    await player.resume();
    message.reply({ embeds: [embeds.success('تم استئناف التشغيل ▶️ .')] });
  },
};
