const embeds = require('../utils/embeds');
const checks = require('../utils/checks');

module.exports = {
  name: 'stop',
  aliases: ['leave', 'dc', 'disconnect', 'وداع'],
  description: 'أوقِف الموسيقى وامسح القائمة واخرج من القناة',

  async execute(message, args, client) {
    const vcErr = checks.voiceChecks(message);
    if (vcErr) return message.reply({ embeds: [embeds.error(vcErr)] });

    const player = client.lavalink.getPlayer(message.guild.id);
    if (!player) return message.reply({ embeds: [embeds.error('البوت غير متصل بأي قناة صوتية!')] });

    const chErr = checks.sameChannel(message, player);
    if (chErr) return message.reply({ embeds: [embeds.error(chErr)] });

    await player.destroy();
    message.reply({ embeds: [embeds.success('⏹️  تم إيقاف الموسيقى ومسح القائمة والخروج من القناة.')] });
  },
};
