const { PermissionFlagsBits } = require('discord.js');

module.exports = {
  voiceChecks(message) {
    const voiceChannel = message.member?.voice?.channel;
    if (!voiceChannel) return 'يجب أن تكون في قناة صوتية أولاً!';

    const me = message.guild?.members?.me;
    if (!me) return 'حدث خطأ غير متوقع!';

    const perms = voiceChannel.permissionsFor(me);
    if (!perms?.has(PermissionFlagsBits.Connect)) return 'لا أملك صلاحية الانضمام إلى قناتك الصوتية!';
    if (!perms?.has(PermissionFlagsBits.Speak)) return 'لا أملك صلاحية التحدث في قناتك الصوتية!';

    return null;
  },

  playerChecks(client, guildId) {
    const player = client.lavalink.getPlayer(guildId);
    if (!player) return 'لا تُشغَّل أيُّ موسيقى الآن!';
    return player;
  },

  sameChannel(message, player) {
    const userVC = message.member?.voice?.channelId;
    const botVC = player.voiceChannelId;
    if (botVC && userVC !== botVC) return 'يجب أن تكون في نفس القناة الصوتية للبوت!';
    return null;
  },

  fullCheck(message, client) {
    const vcErr = this.voiceChecks(message);
    if (vcErr) return { error: vcErr };

    const player = this.playerChecks(client, message.guild.id);
    if (typeof player === 'string') return { error: player };

    const chErr = this.sameChannel(message, player);
    if (chErr) return { error: chErr };

    return { player };
  },
};
