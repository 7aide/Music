const { EmbedBuilder } = require('discord.js');
const { COLORS } = require('../../config/bot');

function formatTime(ms) {
  if (!ms || ms <= 0) return '0:00';
  const s = Math.floor(ms / 5000);
  const m = Math.floor(s / 60);
  const h = Math.floor(m / 60);
  const ss = (s % 60).toString().padStart(2, '0');
  const mm = (m % 60).toString().padStart(2, '0');
  return h > 0 ? `${h}:${mm}:${ss}` : `${m}:${ss}`;
}

const BAR_SIZE = 10;
const BAR_CHAR = '▬';
const CURSOR = '🔘';

function progressBar(currentMs, totalMs) {
  if (!totalMs || totalMs <= 0) return BAR_CHAR.repeat(BAR_SIZE) + CURSOR + BAR_CHAR.repeat(0);
  const pct = Math.min(Math.max(currentMs / totalMs, 0), 1);
  const pos = Math.round(pct * BAR_SIZE);
  const left  = BAR_CHAR.repeat(pos);
  const right = BAR_CHAR.repeat(Math.max(0, BAR_SIZE - pos));
  return `${left}${CURSOR}${right}`;
}

function volumeBar(vol, size = 10) {
  const v = Math.max(0, Math.min(100, vol || 0));
  const filled = Math.round((v / 100) * size);
  return '🟩'.repeat(filled) + '⬛'.repeat(size - filled);
}

function getRequester(track) {
  if (!track?.requester) return 'غير معروف';
  if (typeof track.requester === 'string') return track.requester;
  return `<@${track.requester.id}>`;
}

function estimatePosition(player) {
  if (!player) return 0;
  if (player.paused) return player.position || 0;
  const lastPos  = player.position || 0;
  const lastTime = player.lastPositionChange || Date.now();
  const elapsed  = Date.now() - lastTime;
  return Math.min(lastPos + elapsed, player.queue?.current?.info?.duration || lastPos);
}

module.exports = {
  formatTime,
  progressBar,
  volumeBar,
  getRequester,
  estimatePosition,

  error(desc) {
    return new EmbedBuilder().setColor(COLORS.ERROR).setDescription(`❌  ${desc}`);
  },

  success(desc) {
    return new EmbedBuilder().setColor(COLORS.SUCCESS).setDescription(`  ${desc}`);
  },

  warning(desc) {
    return new EmbedBuilder().setColor(COLORS.WARNING).setDescription(`⚠️  ${desc}`);
  },

  info(desc) {
    return new EmbedBuilder().setColor(COLORS.INFO).setDescription(`${desc}`);
  },

  nowPlaying(player, track, client, positionMs) {
    const info      = track?.info || {};
    const title     = info.title    || 'أغنية غير معروفة';
    const uri       = 'https://discord.gg/mJ7TuqrE4s';
    const author    = info.author   || 'غير معروف';
    const duration  = info.duration || 0;
    const artwork   = info.artworkUrl || info.thumbnail || null;
    const isStream  = info.isStream || false;
    const pos       = typeof positionMs === 'number' ? positionMs : (player?.position || 0);
    const requester = getRequester(track);
    const repeatLabels = { 0: 'لا يوجد', 1: 'أغنية واحدة', 2: 'القائمة كاملة' };
    const repeatMode = repeatLabels[player?.repeatMode] ?? 'لا يوجد';

    let desc;
    if (isStream) {
      desc =
        `### [${title}](${uri})\n` +
        `${author}\n\n` +
        `${BAR_CHAR.repeat(BAR_SIZE)}${CURSOR}${BAR_CHAR.repeat(0)}\n` +
        `🔵  [∞]  🔊`;
    } else {
      desc =
        `### [${title}](${uri})\n` +
        `:arrow_forward:${progressBar(pos, duration)} :clock3:\`[${formatTime(pos)} / ${formatTime(duration)}] \``;
    }

    const embed = new EmbedBuilder()
      .setColor(COLORS.PRIMARY)
      .setDescription(`${desc}\n${requester}`)
      .setTimestamp();

    if (artwork) embed.setThumbnail(artwork);

    return embed;
  },
    
  
  playStarted(track) {
    const info     = track?.info || {};
    const title    = info.title  || 'أغنية غير معروفة';
    const uri      = 'https://discord.gg/mJ7TuqrE4s';
    const author   = info.author || 'غير معروف';
    const duration = info.duration || 0;
    const isStream = info.isStream || false;

    return (
      
      `:notes:${title} تمت الاضافة الى القائمة  (\`${formatTime(duration)}\`)`
        );
  },

  trackAdded(track, position) {
    const info     = track?.info || {};
    const title    = info.title  || 'أغنية غير معروفة';
    const uri      = info.uri    || null;
    const duration = info.duration || 0;
    const artwork  = info.artworkUrl || null;

    const embed = new EmbedBuilder()
      .setColor(COLORS.INFO)
      .setDescription(
        `**✅  أُضيفت إلى قائمة الانتظار**\n` +
        `### ${uri ? `[${title}](${uri})` : title}\n` +
        `\`${formatTime(duration)}\`  •  الموقع **#${position}** في القائمة`
      );

    if (artwork) embed.setThumbnail(artwork);
    return embed;
  },

  playlistAdded(playlist, count) {
    const name = playlist?.info?.name || playlist?.name || 'قائمة تشغيل';
    const uri  = playlist?.info?.uri  || playlist?.uri  || null;

    return new EmbedBuilder()
      .setColor(COLORS.SUCCESS)
      .setDescription(
        `**✅  أُضيفت قائمة التشغيل**\n` +
        `### ${uri ? `[${name}](${uri})` : name}\n` +
        `تمت إضافة \`${count}\` أغنية إلى قائمة الانتظار`
      );
  },

  queue(player, page = 1) {
    const tracks     = player?.queue?.tracks || [];
    const current    = player?.queue?.current || null;
    const perPage    = 10;
    const totalPages = Math.ceil(tracks.length / perPage) || 1;
    const start      = (page - 1) * perPage;
    const slice      = tracks.slice(start, start + perPage);

    let desc = '';

    if (current) {
      const info = current.info || {};
      const pos  = player?.position || 0;
      const dur  = info.duration || 0;
      const titleLink = info.uri ? `[${info.title}](${info.uri})` : (info.title || '؟');
      desc += `**▶️  يُشغَّل الآن**\n${titleLink}  \`${formatTime(dur)}\`\n`;
      desc += `${progressBar(pos, dur)}\n\n`;
    }

    if (slice.length) {
      desc += slice.map((t, i) => {
        const info  = t.info || {};
        const title = info.uri ? `[${info.title}](${info.uri})` : (info.title || '؟');
        return `\`${start + i + 1}.\`  ${title}  \`${formatTime(info.duration)}\``;
      }).join('\n');
    } else if (!current) {
      desc = '📭  قائمة الانتظار فارغة.';
    }

    const totalDur = tracks.reduce((a, t) => a + (t.info?.duration || 0), 0);

    return new EmbedBuilder()
      .setColor(COLORS.QUEUE)
      .setTitle('📋  قائمة الانتظار')
      .setDescription(desc.slice(0, 4096))
      .setFooter({
        text: `الصفحة ${page} من ${totalPages}  •  ${tracks.length} أغنية  •  المدة الإجمالية: ${formatTime(totalDur)}  •  الصوت: ${player?.volume || 0}%`,
      });
  },
};
