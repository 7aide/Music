const store = new Map();

module.exports = {
  set(guildId, data) {
    const existing = store.get(guildId);
    if (existing?.interval) clearInterval(existing.interval);
    store.set(guildId, data);
  },

  get(guildId) {
    return store.get(guildId);
  },

  clear(guildId) {
    const existing = store.get(guildId);
    if (existing?.interval) clearInterval(existing.interval);
    store.delete(guildId);
  },
};
