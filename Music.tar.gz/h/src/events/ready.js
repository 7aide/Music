const { ActivityType } = require('discord.js');
const chalk = require('chalk');

module.exports = {
  name: 'ready',
  once: true,

  async execute(client) {
    console.log(chalk.green(`✅ تسجيل الدخول: ${client.user.tag}`));
    console.log(chalk.blue(`📡 الخوادم: ${client.guilds.cache.size}`));

    try {
      await client.lavalink.init({
        id: client.user.id,
        username: client.user.username,
      });
      console.log(chalk.cyan('🎵 تم تهيئة LavalinkManager بنجاح'));
    } catch (err) {
      console.error(chalk.red('❌ فشل تهيئة Lavalink:'), err.message);
    }

    const activities = [
      { name: `!help | ${client.guilds.cache.size} خادم`, type: ActivityType.Listening },
      { name: 'الموسيقى 🎵', type: ActivityType.Playing },
      { name: 'Made by Hai Der & Vita', type: ActivityType.Watching },
    ];

    let i = 0;
    const setActivity = () => {
      client.user.setActivity(activities[i % activities.length]);
      i++;
    };
    setActivity();
    setInterval(setActivity, 20_000);
  },
};
