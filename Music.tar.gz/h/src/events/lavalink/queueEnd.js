const embeds = require('../../utils/embeds');
const playerStore = require('../../utils/playerStore');

module.exports = {
  name: 'queueEnd',

  async execute(player, track, client) {
    playerStore.clear(player.guildId);
    const channel = client.channels.cache.get(player.textChannelId);
    channel?.send({
      embeds: [embeds.success('انتهت قائمة الانتظار. اكتب `!play` لتشغيل المزيد 🎵')],
    }).catch(() => {});
  },
};
