const embeds = require('../../utils/embeds');

module.exports = {
  name: 'trackStuck',

  async execute(player, track, payload, client) {
    const channel = client.channels.cache.get(player.textChannelId);
    await player.skip().catch(() => {});
    channel?.send({
      embeds: [embeds.warning(`الأغنية **${track?.info?.title?.slice(0, 50) || '؟'}** توقفت! جاري التخطي...`)],
    }).catch(() => {});
  },
};
