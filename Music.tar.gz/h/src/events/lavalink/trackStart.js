const embeds = require('../../utils/embeds');
const playerStore = require('../../utils/playerStore');

module.exports = {
  name: 'trackStart',

  async execute(player, track, payload, client) {
    playerStore.clear(player.guildId);

    if (!player.textChannelId) return;
    const channel = client.channels.cache.get(player.textChannelId);
    if (!channel) return;

    if (player.queue.previous?.length > 0) {
      try {
      
        await channel.send({ content: embeds.playStarted(track) });
      } catch (err) {
        console.error('trackStart error:', err.message);
      }
    }
  },
};
