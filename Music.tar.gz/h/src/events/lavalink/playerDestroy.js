const playerStore = require('../../utils/playerStore');

module.exports = {
  name: 'playerDestroy',

  execute(player, reason, client) {
    playerStore.clear(player.guildId);
  },
};
