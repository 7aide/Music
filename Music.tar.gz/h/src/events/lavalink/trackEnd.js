const playerStore = require('../../utils/playerStore');

module.exports = {
  name: 'trackEnd',

  async execute(player, track, payload, client) {
    playerStore.clear(player.guildId);

    const reason = payload?.reason;

    if (reason === 'replaced' || reason === 'stopped') return;

    if (player.repeatMode === 'track') {
      await player.queue.add(track, 0);
      await player.play({ paused: false });
      return;
    }

    if (player.queue.tracks.length > 0) {
      await player.play({ paused: false });
    }
  },
};
