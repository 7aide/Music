const embeds = require('../../utils/embeds');

module.exports = {
  name: 'trackError',

  async execute(player, track, payload, client) {
    console.error(`trackError [${player.guildId}]: ${payload?.exception?.message || 'Unknown'}`);
    const channel = client.channels.cache.get(player.textChannelId);
    if (!channel) return;
    channel.send({
      embeds: [embeds.error(`حدث خطأ في تشغيل **${track?.info?.title || 'الأغنية'}**\n\`${payload?.exception?.message || 'خطأ غير معروف'}\``)],
    }).catch(() => {});
  },
};
