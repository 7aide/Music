require('dotenv').config();
const { Client, GatewayIntentBits, Collection } = require('discord.js');
const { LavalinkManager }  = require('lavalink-client');
const chalk                = require('chalk');

const nodes          = require('./config/nodes');
const { PREFIX, DEFAULT_VOLUME, SEARCH_PLATFORM, DEBUG } = require('./config/bot');
const commandHandler = require('./src/handlers/commandHandler');
const eventHandler   = require('./src/handlers/eventHandler');

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildVoiceStates,
  ],
});

client.lavalink = new LavalinkManager({
  nodes,

  sendToShard: (guildId, payload) => {

    if (!client.isReady()) return;
    const guild = client.guilds.cache.get(guildId);
    if (!guild) return;
    guild.shard?.send(payload);
  },

  client: {
    id: process.env.CLIENT_ID,
    username: 'MusicBot',
  },

  autoSkip: false,

  playerOptions: {
    clientBasedPositionUpdateInterval: 150,
    defaultSearchPlatform: SEARCH_PLATFORM,
    volumeDecrementer: 0.75,
    applyVolumeAsFilter: false,

    onDisconnect: {
      autoReconnect: true,
      destroyPlayer: false,
    },

    onEmptyQueue: {
      destroyAfterMs: 30_000,
    },

    useUnresolvedData: true,
  },

  queueOptions: {
    maxPreviousTracks: 25,
  },

  advancedOptions: {
    enableDebugEvents: DEBUG,
  },
});

commandHandler.load(client);
eventHandler.load(client);
commandHandler.handle(client);

client.on('raw', (d) => {
  if (client.lavalink) client.lavalink.sendRawData(d);
});

console.log(chalk.cyan(`
╔══════════════════════════════════════╗
║            Music Bot                 ║
║       Made By Hai Der & Vita         ║
╚══════════════════════════════════════╝`));

console.log(chalk.yellow(`📡 النودات المحملة: ${nodes.length}`));
nodes.forEach(n => {
  const ssl = n.secure ? chalk.green('🔒 SSL') : chalk.gray('🔓 No-SSL');
  console.log(`   ${ssl} ${chalk.white(n.host)}:${chalk.cyan(n.port)}`);
});

client.login(process.env.DISCORD_TOKEN).catch(err => {
  console.error(chalk.red('❌ فشل تسجيل الدخول:'), err.message);
  process.exit(1);
});

process.on('unhandledRejection', (err) => {
  console.error(chalk.red('❌ Unhandled Rejection:'), err?.message || err);
});
process.on('uncaughtException', (err) => {
  console.error(chalk.red('❌ Uncaught Exception:'), err?.message || err);
});
