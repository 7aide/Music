require('dotenv').config();

function parseNode(index) {
  const suffix   = index === 1 ? '' : `_${index}`;
  const host     = process.env[`LAVALINK_HOST${suffix}`];
  const port     = process.env[`LAVALINK_PORT${suffix}`];
  const password = process.env[`LAVALINK_PASSWORD${suffix}`];
  const secure   = process.env[`LAVALINK_SECURE${suffix}`];

  if (!host || !port || !password) return null;

  const isSecure   = secure === 'true' || secure === '1';
  const parsedPort = parseInt(port);

  const finalSecure = isSecure && parsedPort === 443;

  if (isSecure && parsedPort !== 443) {
    console.warn(
      `⚠️  Node-${index}: LAVALINK_SECURE=true مع port=${parsedPort} غير مدعوم.\n` +
      `   تم التحويل لـ secure=false تلقائياً.\n` +
      `   💡 للـ SSL: اجعل port=443 أو استخدم nginx على 443 → ${host}:${parsedPort}`
    );
  }

  return {
    id: `Node-${index}`,
    host,
    port: parsedPort,
    authorization: password,
    secure: finalSecure,
    requestTimeout: 10_000,
    retryAmount: 5,
    retryDelay: 3_000,
  };
}

const nodes = [];
for (let i = 1; i <= 10; i++) {
  const node = parseNode(i);
  if (node) nodes.push(node);
  else if (i > 1) break;
}

if (nodes.length === 0) {
  console.error('❌ لا يوجد أي نود Lavalink في ملف .env!');
  process.exit(1);
}

module.exports = nodes;
