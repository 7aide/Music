require('dotenv').config();

module.exports = {
  PREFIX: process.env.PREFIX || '!',
  DEFAULT_VOLUME: parseInt(process.env.DEFAULT_VOLUME) || 80,
  MAX_QUEUE_SIZE: parseInt(process.env.MAX_QUEUE_SIZE) || 500,
  SEARCH_PLATFORM: process.env.SEARCH_PLATFORM || 'ytsearch',
  DEBUG: process.env.DEBUG === 'true',

  COLORS: {
    PRIMARY:  0x1DB954,
    ERROR:    0xFF4C4C,
    WARNING:  0xF39C12,
    INFO:     0x3498DB,
    QUEUE:    0x9B59B6,
    STOP:     0xE74C3C,
    SUCCESS:  0x2ECC71,
    NEUTRAL:  0x95A5A6,
  },

  EMOJIS: {
    PLAY:     '▶️',
    PAUSE:    '⏸️',
    STOP:     '⏹️',
    SKIP:     '⏭️',
    QUEUE:    '📋',
    VOLUME:   '🔊',
    LOOP:     '🔁',
    SHUFFLE:  '🔀',
    MUSIC:    '🎵',
    ERROR:    '❌',
    SUCCESS:  '✅',
    LOADING:  '🔍',
    NODE:     '🌐',
    FILTER:   '🎛️',
    SEEK:     '⏩',
  },

  REPEAT_MODES: {
    0: '➡️ لا يوجد',
    1: '🔂 أغنية',
    2: '🔁 قائمة',
  },

  SEARCH_PLATFORMS: {
    ytmsearch:  'YouTube Music',
    ytsearch:   'YouTube',
    scsearch:   'SoundCloud',
    spsearch:   'Spotify',
    dzsearch:   'Deezer',
    ymsearch:   'Yandex Music',
  },
};
